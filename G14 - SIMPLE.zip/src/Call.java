
public class Call 
{
	public boolean other_module;
	public String functionName;
	public String functionDeclaration;
	public String[] args;
	
	public Call()
	{
		
	}
}
